<?php

namespace App;

use Amsgames\LaravelShop\Models\ShopCouponModel;

class Coupon extends ShopCouponModel
{
    //
}
