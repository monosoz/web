@extends('layouts.app')

@section('content')
<div class="container">
  <div class="row">
    <div class="col-sm-12 col-lg-10 col-lg-offset-1">
      <div class="panel panel-default">
        <div class="panel-heading">Checkout</div>
        <div class="panel-body">
          <div>
            <p>Name: {{$user->name}} <a class="pull-right" href="#">edit</a></p>
            <p>Mobile Number: {{$user->mobile_number}} <a class="pull-right" href="#">edit</a></p>
            <p>Email: {{$user->email}} <a class="pull-right" href="#">edit</a></p>
          </div>
          <hr>
          <div>
            <p>Delivery Address:</p>
            <div class="add-text col-xs-6">
              <span class="add-field"><h>Name:</h></span><h>{{$selectadd->name}}</h><br>
              <span class="add-field"><h>Contact:</h></span><h>{{$selectadd->mobile_number}}</h><br>
              <span class="add-field"><h>Address:</h></span><h>{{$selectadd->address}}</h><br>
              <span class="add-field"><h>Pincode:</h></span><h>{{$selectadd->pincode}}</h><br>
              
            </div>
            <div class="add-map col-xs-6 col-sm-4">
              <img class="img-responsive pull-right" src={{"https://maps.googleapis.com/maps/api/staticmap?key=AIzaSyCfq4C_gKmaC-onksNumXb9cWfY4omo3pE&center=28.5383277,77.1980605&zoom=11&size=200x200&maptype=roadmap&markers=color:red|" . $selectadd->lat . "," . $selectadd->lng}}>
            </div>
            <hr>
            <div>
              <p>New Address:
              </p>
              <form class="form-horizontal" method="POST" action="/user/address">
                {{ csrf_field() }}
                <div class="col-sm-6">                @include('blocks.addressform')
                  <div id="mapinput"></div>
                </div>
                <div class="col-sm-6">
                  <div id="new_map"></div>
                </div>
              </form>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
@endsection

@section('scripts')
<script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyCfq4C_gKmaC-onksNumXb9cWfY4omo3pE"></script>
<script src="{{ url('map.js') }}"></script>
@endsection