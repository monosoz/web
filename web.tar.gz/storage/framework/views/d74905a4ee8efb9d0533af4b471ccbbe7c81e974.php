<?php $__env->startSection('content'); ?>
<div class="container">
  <div class="row">
    <div class="col-sm-12 col-lg-10 col-lg-offset-1">
      <div class="panel panel-default">
        <div class="panel-heading">Checkout</div>
        <div class="panel-body">
          <div>
            <p>Name: <?php echo e($user->name); ?> <a class="pull-right" href="#">edit</a></p>
            <p>Mobile Number: <?php echo e($user->mobile_number); ?> <a class="pull-right" href="#">edit</a></p>
            <p>Email: <?php echo e($user->email); ?> <a class="pull-right" href="#">edit</a></p>
          </div>
          <hr>
          <div>
            <?php if(count($user->locations) === 0): ?>
            <p>Enter Delivery Address:</p>
            <?php else: ?>
            <div class="clearfix">
              <p>Select Delivery Address:</p>
                <?php foreach($user->locations->sortByDesc('updated_at') as $location): ?>
                <div class="addcard col-lg-10 col-lg-offset-1">
                  <?php echo $__env->make('blocks.addresscard', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                </div>
                <?php endforeach; ?>
            </div>
            <?php endif; ?>
            <hr>
            <div class="clearfix">
              <p>New Address:
              </p>
              <form class="form-horizontal" method="POST" action="/user/address">
                <?php echo e(csrf_field()); ?>

                <div class="col-sm-6">                <?php echo $__env->make('blocks.addressform', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                <div id="mapinput"></div>
                </div>
                <div class="col-sm-6">
                  <div id="new_map"></div>
                </div>
              </form>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyCfq4C_gKmaC-onksNumXb9cWfY4omo3pE"></script>
    <script src="<?php echo e(url('map.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>