<?php $__env->startSection('content'); ?>
    <div class="container">
      <div class="col-ls-12">
        <?php echo $__env->make('blocks.product', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
      </div>
    </div>

    <!-- Collapsed Hamburger -->

    <div id="toTop" type="button" class="carticon" data-toggle="modal" data-target="#app-cart-modal">

      <i class="fa fa-shopping-cart fa-3x"aria-hidden="true"></i>
    </div>
    <div class="modal fade" id="app-cart-modal">
    <div class="cart panel panel-default modal-content">
      <div class="panel-heading">
        <button type="button" class="" data-dismiss="modal">&times;</button>
        &nbspCart (<?php echo e($cart->id); ?>)
        <span class="pull-right">Items: <?php echo e($cart->count); ?></span>
      </div>
      <div>
          <?php echo $__env->make('blocks.cart', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
      </div>
      <div class="panel-footer">
        <a href="<?php echo e(url('checkout')); ?>">Checkout: <i class="fa fa-inr"></i>&nbsp<?php echo e($cart->total); ?></a>
      </div>
    </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>