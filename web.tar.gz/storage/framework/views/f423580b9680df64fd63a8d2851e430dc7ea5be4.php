 <div>
  <?php if(count($products) === 0): ?>
  <p>Comming soon. </p>
  <?php else: ?>
  <div class="row">
    <div class="tag" type="button" class="tag-btn" data-toggle="collapse" data-target="#tag1-collapse">> <?php echo e($tags->find(1)->name); ?></div>
    <div class="collapse in" id="tag1-collapse">
      <?php foreach($tags->find(1)->products as $product): ?>
      <?php echo $__env->make('blocks.itemcard', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
      <?php endforeach; ?>
    </div>
  </div>
  <div class="row">
    <div class="tag" type="button" class="tag-btn" data-toggle="collapse" data-target="#tag2-collapse">> <?php echo e($tags->find(2)->name); ?></div>
    <div class="collapse in" id="tag2-collapse">
      <?php foreach($tags->find(2)->products as $product): ?>
      <?php echo $__env->make('blocks.itemcard', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
      <?php endforeach; ?>
    </div>
  </div>
  <?php endif; ?>
</div>