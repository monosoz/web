<div class="iccon col-md-4 col-sm-6">
  <div class="itemcard card clearfix">
    <img class="pthumb" src="data:image/jpeg;base64,<?php echo e(base64_encode($product->image)); ?>">
    <span class="pname"><?php echo e($product->name); ?></span>
    <p class="textclip"><?php echo e($product->description); ?></p>
    <form class="buy-form" action="<?php echo e(url('cart')); ?>" method="POST">
      <?php foreach($product->variants->all() as $variant): ?>
      <?php echo e(csrf_field()); ?>

      <button type="submit" class="btn btn-primary" name="id" value="<?php echo e($variant->id); ?>"><?php echo e(substr("$variant->sku", -1)); ?>&nbsp
        <i class="fa fa-inr">&nbsp</i><?php echo e($variant->price+0); ?>

      </button>
      <?php endforeach; ?>
    </form>
  </div>
</div>