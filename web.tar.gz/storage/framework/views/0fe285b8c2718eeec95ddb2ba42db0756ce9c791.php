<table class="table table-hover">
    <?php foreach($cart->items as $item): ?>
    <tr>
        <td><span><?php echo e($item->displayName); ?></span></td>
        <td><i class="fa fa-inr"></i><span> <?php echo e($item->price + 0); ?></span></td>
        <td>
           <form action="<?php echo e(url('cart/'.$item->sku)); ?>" method="POST">
                <?php echo e(csrf_field()); ?>

                <button type="submit" name="action" value="add" class="btn-link">
                    <i class="fa fa-plus-square" aria-hidden="true"></i>
                </button>
                <span><?php echo e($item->quantity); ?></span>
                <button type="submit" name="action" value="rm" class="btn-link">
                    <i class="fa fa-minus-square" aria-hidden="true"></i>
                </button>
            </form>
        </td>
    </tr>
    <?php endforeach; ?>
</table>
