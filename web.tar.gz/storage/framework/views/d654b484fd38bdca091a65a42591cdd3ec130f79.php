 <div>
  <?php if(count($products) === 0): ?>
    <p>No content on this blog yet. </p>
  <?php else: ?>
    <?php foreach($products as $product): ?>
    <div class="col-md-4 col-sm-6 iccon">
      <div class="itemcard clearfix">
        <img class="pthumb" src="data:image/jpeg;base64,<?php echo e(base64_encode($product->image)); ?>">
        <h3><?php echo e($product->name); ?></h3>
        <p><?php echo e($product->description); ?></p>
        <button type="button" class="btn btn-primary">
        <i class="fa fa-inr"></i> 000</button>
      </div>
    </div>
    <?php endforeach; ?>
  <?php endif; ?>
</div>